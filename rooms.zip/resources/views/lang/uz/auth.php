<?php

return [
    'failed' => 'Kiritilgan maʼlumotlar bizdagi yozuvlarga mos kelmadi.',
    'password' => 'Kiritilgan parol noto‘g‘ri.',
    'throttle' => 'Kirish uchun juda ko‘p urinishlar. Iltimos, :seconds soniyadan keyin yana urinib ko‘ring.',
];

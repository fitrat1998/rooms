<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Tahrirlash</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Bosh sahifa</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Foydalanuvchi</a></li>
                        <li class="breadcrumb-item active">Tahrirlash</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <section class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Tahrirlash</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <form action="<?php echo e(route('rooms.update',$room->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>


                            <div class="form-group">
                                <label>Bino tanlang</label>
                                <select id="building" name="building" class="form-control" required>
                                    <option value="">Bino tanlang</option>
                                    <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($building->id); ?>" <?php echo e($building->id == $room->floor->building_id ? 'selected' : ''); ?>>
                                            <?php echo e($building->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>

                            <div class="form-group">
                                <label>Qavat</label>
                                <select id="floors" name="floors" class="form-control" required id="floors">
                                    <option value="">Avval binoni tanlang</option>
                                    <?php $__currentLoopData = $floors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($floor->id); ?>" <?php echo e($floor->id == $room->floor->id ? 'selected' : ''); ?>>
                                            <?php echo e($floor->number); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>

                            <div class="form-group">
                                <label>Xona raqami</label>
                                <input type="number" name="rooms"
                                       class="form-control <?php echo e($errors->has('floors') ? "is-invalid":""); ?>"
                                       value="<?php echo e(old('rooms',$room->number)); ?>" required>
                                <?php if($errors->has('rooms')): ?>
                                    <span class="error invalid-feedback"><?php echo e($errors->first('rooms')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Joylar soni</label>
                                <input type="number" name="beds"
                                       class="form-control <?php echo e($errors->has('floors') ? "is-invalid":""); ?>"
                                       value="<?php echo e($beds); ?>" required>
                                <?php if($errors->has('beds')): ?>
                                    <span class="error invalid-feedback"><?php echo e($errors->first('beds')); ?></span>
                                <?php endif; ?>
                            </div>


                            <div class="form-group">
                                <label>Izoh (majburiy emas)</label>
                                <?php
                                    $comment = old('comment', isset($room) ? $room->comment : '');
                                ?>
                                <textarea name="comment" id="comment"
                                          class="form-control <?php echo e($errors->has('comment') ? 'is-invalid' : ''); ?>"><?php echo e($comment !== 'mavjud emas' ? $comment : ''); ?></textarea>
                                <?php if($errors->has('comment')): ?>
                                    <span class="error invalid-feedback"><?php echo e($errors->first('comment')); ?></span>
                                <?php endif; ?>
                            </div>


                            <div class="form-group">
                                <button type="submit" class="btn btn-success float-right">Saqlash</button>
                                <a href="<?php echo e(route('buildings.index')); ?>" class="btn btn-danger float-left">Bekor
                                    qilish</a>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\rooms\resources\views/rooms/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Bino</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Bosh sahifa</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('buildings.index')); ?>">Binolar</a></li>
                        <li class="breadcrumb-item active">Qo'shish</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-sm-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Qo'shish</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form action="<?php echo e(route('rooms.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Bino tanlang</label>
                                <select id="building" name="building" class="form-control" required id="building">
                                    <option value="">Bino tanlang</option>
                                    <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($building->id); ?>"><?php echo e($building->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Qavatlar soni</label>
                                <select id="floors" name="floors" class="form-control" required id="floors">
                                    <option value="">Avval binoni tanlang</option>
                                    <!-- AJAX orqali yuklanadi -->
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Xona raqami</label>
                                <input type="number" name="rooms"
                                       class="form-control <?php echo e($errors->has('floors') ? "is-invalid":""); ?>"
                                       value="<?php echo e(old('rooms')); ?>" required>
                                <?php if($errors->has('rooms')): ?>
                                    <span class="error invalid-feedback"><?php echo e($errors->first('rooms')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Joylar soni</label>
                                <input type="number" name="beds"
                                       class="form-control <?php echo e($errors->has('floors') ? "is-invalid":""); ?>"
                                       value="<?php echo e(old('beds')); ?>" required>
                                <?php if($errors->has('beds')): ?>
                                    <span class="error invalid-feedback"><?php echo e($errors->first('beds')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Izoh (majburiy emas)</label>
                                <textarea name="comment" id="comment"
                                          class="form-control <?php echo e($errors->has('comment') ? 'is-invalid' : ''); ?>"><?php echo e(old('comment', isset($guest) ? $guest->comment : '')); ?></textarea>
                                <?php if($errors->has('comment')): ?>
                                    <span class="error invalid-feedback"><?php echo e($errors->first('comment')); ?></span>
                                <?php endif; ?>
                            </div>


                            <div class="form-group">
                                <button type="submit" class="btn btn-success float-right">Saqlash</button>
                                <a href="<?php echo e(route('buildings.index')); ?>" class="btn btn-danger float-left">Bekor
                                    qilish</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\rooms\resources\views/rooms/add.blade.php ENDPATH**/ ?>
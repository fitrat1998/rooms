<!-- Sidebar Menu -->
<nav class="mt-2">
    <ul class="nav sidebar-toggle nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu"
        data-accordion="true">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['permission.show', 'roles.show', 'user.show'])): ?>
            <li class="nav-item has-treeview">
                <a href="#"
                   class="nav-link <?php echo e(Request::is('adminpermissions*') || Request::is('role*') || Request::is('user*') ? 'active' : ''); ?>">
                    <i class="fas fa-users-cog"></i>
                    <p>Tuzilma <i class="right fas fa-angle-left"></i></p>
                </a>
                <ul class="nav nav-treeview"
                    style="display: <?php echo e(Request::is('adminpermissions*') || Request::is('role*') || Request::is('user*') ? 'block' : 'none'); ?>;">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission.show')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('adminpermissions.index')); ?>"
                               class="nav-link <?php echo e(Request::is('adminpermissions*') ? 'active' : ''); ?>">
                                <i class="fas fa-key"></i>
                                <p>Ruxsatlar</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.show')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('roles.index')); ?>"
                               class="nav-link <?php echo e(Request::is('role*') ? 'active' : ''); ?>">
                                <i class="fas fa-user-lock"></i>
                                <p>Rollar</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.show')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('users.index')); ?>"
                               class="nav-link <?php echo e(Request::is('user*') ? 'active' : ''); ?>">
                                <i class="fas fa-user-friends"></i>
                                <p>Foydalanuvchilar</p>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['permission.show', 'buildings.show', 'rooms.show'])): ?>
            <li class="nav-item has-treeview">
                <a href="#" class="nav-link <?php echo e(Request::is('buildings*') || Request::is('rooms*') ? 'active' : ''); ?>">
                    <i class="fa-solid fa-school-flag"></i>
                    <p>Turar joy <i class="right fas fa-angle-left"></i></p>
                </a>
                <ul class="nav nav-treeview"
                    style="display: <?php echo e(Request::is('buildings*') || Request::is('rooms*') ? 'block' : 'none'); ?>;">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('buildings.show')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('buildings.index')); ?>"
                               class="nav-link <?php echo e(Request::is('buildings*') ? 'active' : ''); ?>">
                                <i class="fa-solid fa-school-flag"></i>
                                <p>Binolar</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rooms.show')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('rooms.index')); ?>"
                               class="nav-link <?php echo e(Request::is('rooms*') ? 'active' : ''); ?>">
                                <i class="fa-solid fa-person-shelter"></i>
                                <p>Xonalar</p>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['guests.show', 'citizenships.show', 'visits.index', 'visits.archived'])): ?>
            <li class="nav-item has-treeview <?php echo e(Request::routeIs(['guests.*', 'citizenships.*', 'visits.*', 'archived.*']) ? 'menu-open' : ''); ?>">
                <a href="#"
                   class="nav-link <?php echo e(Request::routeIs(['guests.*', 'citizenships.*', 'visits.*', 'archived.*']) ? 'active' : ''); ?>">
                    <i class="fa-solid fa-users"></i>
                    <p>Mehmonlar <i class="right fas fa-angle-left"></i></p>
                </a>
                <ul class="nav nav-treeview">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('guests.show')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('guests.index')); ?>"
                               class="nav-link <?php echo e(Request::routeIs('guests.*') ? 'active' : ''); ?>">
                                <i class="fa-solid fa-user-tie"></i>
                                <p>Mehmonlar</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('citizenships.show')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('citizenships.index')); ?>"
                               class="nav-link <?php echo e(Request::routeIs('citizenships.*') ? 'active' : ''); ?>">
                                <i class="fa-solid fa-earth-asia"></i>
                                <p>Mamlakatlar</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('visits.index')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('visits.index')); ?>"
                               class="nav-link <?php echo e(Request::routeIs('visits.index') ? 'active' : ''); ?>">
                                <i class="fa-solid fa-shoe-prints"></i>
                                <p>Tashriflar</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('visits.archived')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('visits.archived')); ?>"
                               class="nav-link <?php echo e(Request::is('visits/archived') ? 'active' : ''); ?>">
                                <i class="fa-solid fa-folder-tree"></i>
                                <p>Arxiv</p>
                            </a>
                        </li>
                    <?php endif; ?>

                </ul>
            </li>
        <?php endif; ?>
    </ul>
</nav>
<!-- /.sidebar-menu -->
<?php /**PATH E:\OSPanel\domains\rooms\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>
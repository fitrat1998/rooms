<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Bino</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Bosh sahifa</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Binolar</a></li>
                        <li class="breadcrumb-item active">Qo'shish</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <section class="content">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 col-sm-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title ">Qo'shish</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <form action="<?php echo e(route('visits.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>


                            <form action="<?php echo e(route('visits.store')); ?>"
                                  method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="guest_id"
                                       value="<?php echo e($guest->id); ?>">

                                <div class="form-group">
                                    <h6 class="float-lg-left">Fish</h6>
                                    <input type="text"
                                           class="form-control <?php echo e($errors->has('name') ? "is-invalid":""); ?>"
                                           value="<?php echo e($guest->fullname); ?>" disabled>
                                    <?php if($errors->has('name')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <h6 class="float-lg-left">Lavozimi</h6>
                                    <input type="text" name="position"
                                           class="form-control <?php echo e($errors->has('name') ? "is-invalid":""); ?>"
                                           value="<?php echo e(old('position')); ?>">
                                    <?php if($errors->has('position')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('position')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <h6 class="float-lg-left">Nima maqsadda
                                        kelgan</h6>
                                    <input type="text" name="reason"
                                           class="form-control <?php echo e($errors->has('name') ? "is-invalid":""); ?>"
                                           value="<?php echo e(old('reason')); ?>">
                                    <?php if($errors->has('reason')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('reason')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <h6 class="float-lg-left">Tarif</h6>
                                    <select class="form-control" name="tarif" id="">
                                        <option value="">tarifni tanlang</option>
                                        <option value="free">Bepul</option>
                                        <option value="paid">Pullik</option>
                                    </select>
                                    <?php if($errors->has('tarif')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('tarif')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <h6 class="float-lg-left">Viza</h6><br><br>
                                    <div
                                        class="form-check form-check-inline float-lg-left">
                                        <input type="radio" id="visa_yes"
                                               name="visa" value="yes"
                                               class="form-check-input <?php echo e($errors->has('visa') ? 'is-invalid' : ''); ?>">
                                        <label for="visa_yes"
                                               class="form-check-label">Yes</label>
                                    </div>
                                    <div
                                        class="form-check form-check-inline float-lg-left">
                                        <input type="radio" id="visa_no" name="visa"
                                               value="no"
                                               class="form-check-input <?php echo e($errors->has('visa') ? 'is-invalid' : ''); ?>">
                                        <label for="visa_no"
                                               class="form-check-label">No</label>
                                    </div>
                                    <?php if($errors->has('visa')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('visa')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div><br></div>
                                <div class="form-group period_group"
                                     id="period_group" style="display:none;">
                                    <h6 style="float: left;">Viza muddati
                                        (gacha)</h6>
                                    <input type="text" name="visa_period"
                                           class="form-control <?php echo e($errors->has('visa_period') ? 'is-invalid' : ''); ?>"
                                           value="<?php echo e(old('visa_period')); ?>">
                                    <?php if($errors->has('visa_period')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('visa_period')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <h6 class="float-lg-left">Registratsiya</h6><br><br>
                                    <div
                                        class="form-check form-check-inline float-lg-left">
                                        <input type="radio" id="reg_yes" name="reg"
                                               value="yes"
                                               class="form-check-input <?php echo e($errors->has('reg') ? 'is-invalid' : ''); ?>">
                                        <label for="reg_yes"
                                               class="form-check-label">Yes</label>
                                    </div>
                                    <div
                                        class="form-check form-check-inline float-lg-left">
                                        <input type="radio" id="reg_no" name="reg"
                                               value="no"
                                               class="form-check-input <?php echo e($errors->has('reg') ? 'is-invalid' : ''); ?>">
                                        <label for="reg_no"
                                               class="form-check-label">No</label>
                                    </div>
                                    <?php if($errors->has('reg')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('reg')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div><br></div>
                                <div class="form-group period_group"
                                     id="reg_period_group" style="display:none;">
                                    <h6 style="float: left;">Registratsiya muddati
                                        (gacha)</h6>
                                    <input type="text" name="reg_period"
                                           class="form-control <?php echo e($errors->has('reg_period') ? 'is-invalid' : ''); ?>"
                                           value="<?php echo e(old('reg_period')); ?>">
                                    <?php if($errors->has('reg_period')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('reg_period')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <h6 class="float-lg-left">Bo`sh joylar</h6>
                                    <select class="form-control" name="bed" id="">
                                        <option value="">joyni tanlang</option>
                                        <?php $__currentLoopData = $beds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($bed->id); ?>">
                                                (<?php echo e($bed->number); ?> - bo`sh) (<?php echo e($bed->room->number); ?> - xona)
                                                (<?php echo e($bed->room->floor->number ?? 'Qavat mavjud emas'); ?> - qavat)
                                                (<?php echo e($bed->building($bed->room->floor->building_id) ?? 'Bino mavjud emas'); ?> - Binosi)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('room')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('room')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <h6 class="float-lg-left">Izoh</h6>

                                    <textarea name="comment"
                                              class="form-control <?php echo e($errors->has('comment') ? "is-invalid":""); ?>"
                                              value="<?php echo e(old('comment')); ?>"></textarea>
                                    <?php if($errors->has('comment')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('comment')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <h6 class="float-lg-left">Kelish sanasi</h6>
                                    <input type="text" id="arrive" name="arrive"
                                           class="form-control <?php echo e($errors->has('arrive') ? 'is-invalid' : ''); ?>"
                                           value="<?php echo e(old('arrive')); ?>">
                                    <?php if($errors->has('arrive')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('arrive')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <h6 class="float-lg-left">Qaytib ketish
                                        sanasi</h6>
                                    <input type="text" id="leave" name="leave"
                                           class="form-control <?php echo e($errors->has('leave') ? 'is-invalid' : ''); ?>"
                                           value="<?php echo e(old('leave')); ?>">
                                    <?php if($errors->has('leave')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('leave')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <h6 class="float-lg-left">Band qilish turi</h6>
                                    <select class="form-control" name="order" id="">
                                        <option value="">tanlang</option>
                                        <option value="now">Hozirga band qilish
                                        </option>
                                        <option value="planed">Keyinroqga
                                            rejalashtirish
                                        </option>
                                    </select>
                                    <?php if($errors->has('order')): ?>
                                        <span
                                            class="error invalid-feedback"><?php echo e($errors->first('order')); ?></span>
                                    <?php endif; ?>
                                </div>


                            <div class="form-group">
                                <button type="submit" class="btn btn-success float-right">Saqlash</button>
                                <a href="<?php echo e(route('guests.index')); ?>" class="btn btn-danger float-left">Bekor qilish</a>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\rooms\resources\views/guests/create.blade.php ENDPATH**/ ?>
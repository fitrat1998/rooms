<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Tashriflar</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Bosh sahifa</a></li>
                        <li class="breadcrumb-item active">Tashriflar</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Tashriflar</h3>
                        <a href="<?php echo e(route('visits.create')); ?>" class="btn btn-success btn-sm float-right">
                            <span class="fas fa-plus-circle"></span>
                            Qo'shish
                        </a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.add')): ?>
                        <?php endif; ?>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <!-- Data table -->
                        <table id="dataTable"
                               class="table table-bordered table-striped dataTable dtr-inline table-responsive-lg"
                               user="grid" aria-describedby="dataTable_info" width="100%">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Fish</th>
                                <th>Lavozim</th>
                                <th class="w-25">Kelish sababi</th>
                                <th>Tarif</th>
                                <th>Visa</th>
                                <th class="w-25">Visa muddati</th>
                                <th>Registratsiya</th>
                                <th class="w-25">Registratsiya muddati</th>
                                <th>Joy raqami</th>
                                <th>Xona</th>
                                <th>Izoh</th>
                                <th class="w-25">Kelish sanasi</th>
                                <th class="w-25">Qaytib ketish sanasi</th>
                                <th class="w-25">Status</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($visit->id); ?></td>
                                    <td><?php echo e($visit->guest_id); ?></td>
                                    <td><?php echo e($visit->position); ?></td>
                                    <td><?php echo e($visit->reason); ?></td>
                                    <td>
                                        <?php if($visit->tarif == 'free'): ?>
                                            <span class="btn btn-succuss">Bepul</span>
                                        <?php elseif($visit->tarif == 'paid'): ?>
                                            <span class="btn btn-info">Pullik</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($visit->visa); ?></td>
                                    <td><?php echo e($visit->visa_period); ?></td>
                                    <td><?php echo e($visit->registration); ?></td>
                                    <td><?php echo e($visit->registration_period); ?></td>
                                    <td><?php echo e($visit->bed($visit->bed_id)->number); ?></td>
                                    <td><?php echo e($visit->room($visit->bed($visit->bed_id)->room_id)->number); ?></td>
                                    <td><?php echo e($visit->comment); ?></td>
                                    <td><?php echo e($visit->arrive); ?></td>
                                    <td><?php echo e($visit->leave); ?></td>
                                    <td>
                                        Arxivlangan





                                    </td>




























                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\rooms\resources\views/visits/archived.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-12">
                    <h1 class="text-center">Malumotlar</h1>
                </div>

            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title ">Malumotlar</h3>
                        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success btn-sm float-right">
                            <span class="fas fa-plus-circle"></span>
                            Qo'shish
                        </a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.add')): ?>
                        <?php endif; ?>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <!-- ./row -->
                        <div class="row">
                            <div class="col-12 col-sm-12">
                                <div class="card card-primary card-tabs">
                                    <div class="card-header p-0 pt-1">
                                        <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" id="custom-tabs-one-home-tab"
                                                   data-toggle="pill" href="#custom-tabs-one-home" role="tab"
                                                   aria-controls="custom-tabs-one-home"
                                                   aria-selected="true">Tashriflar</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="custom-tabs-one-profile-tab" data-toggle="pill"
                                                   href="#custom-tabs-one-profile" role="tab"
                                                   aria-controls="custom-tabs-one-profile"
                                                   aria-selected="false">Xonalar</a>
                                            </li>

                                        </ul>
                                    </div>
                                    <div class="card-body">
                                        <div class="tab-content" id="custom-tabs-one-tabContent">
                                            <div class="tab-pane fade show active" id="custom-tabs-one-home"
                                                 role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
                                                <table id="dataTable"
                                                       class="table custom-table table-bordered table-striped dataTable dtr-inline table-responsive-lg"
                                                       user="grid" aria-describedby="dataTable_info" width="100%">
                                                    <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Fish</th>
                                                        <th>Mamlakat</th>
                                                        <th>Xona</th>
                                                        <th>Joyi</th>
                                                        <th>Qavat</th>
                                                        <th>Bino</th>
                                                        <th>Kelish sanasi</th>
                                                        <th>Ketish sanasi</th>

                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($visit->id); ?></td>
                                                            <td><?php echo e($visit->guest->fullname); ?></td>
                                                            <td><?php echo e($visit->guest->citizenship->name); ?></td>
                                                            <td><?php echo e($visit->bed($visit->bed_id)->room->number); ?></td>
                                                            <td><?php echo e($visit->bed($visit->bed_id)->number); ?> - chi</td>
                                                            <td><?php echo e($visit->bed($visit->bed_id)->room->floor->number); ?></td>
                                                            <td><?php echo e($visit->bed($visit->bed_id)->room->floor->building->name); ?></td>
                                                            <td><?php echo e($visit->arrive); ?></td>
                                                            <td><?php echo e($visit->leave); ?></td>


                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="tab-pane fade" id="custom-tabs-one-profile" role="tabpanel"
                                                 aria-labelledby="custom-tabs-one-profile-tab">
                                                <div class="table-responsive-lg">
                                                    <table id="dataTable"
                                                           class="table custom-table table-bordered table-striped roomtable dtr-inline nowrap"
                                                           user="grid" aria-describedby="dataTable_info" width="100%">
                                                        <thead>
                                                        <tr>
                                                            <th class="w-25">ID</th>
                                                            <th class="w-25">Bino</th>
                                                            <th class="w-25">Qavat</th>
                                                            <th class="w-25">Xona</th>
                                                            <th class="w-25">Joylar</th>
                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($room->id); ?></td>
                                                                <td class="w-25"><?php echo e($room->floor->building->name); ?></td>
                                                                <td class="w-25"><span
                                                                        class="btn btn-success"><?php echo e($room->floor->number); ?></span>
                                                                </td>
                                                                <td class="w-25"><span
                                                                        class="btn btn-success"><?php echo e($room->number); ?></span>
                                                                </td>
                                                                <td class="w-25">
                                                                    <?php $__currentLoopData = $room->beds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($bed->status == 'no'): ?>
                                                                            <span
                                                                                class="btn btn-primary"><?php echo e($bed->number); ?></span>
                                                                        <?php elseif($bed->status == 'empty'): ?>
                                                                            <span
                                                                                class="btn btn-danger"><?php echo e($bed->number); ?></span>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                    <!-- /.card -->
                                </div>
                            </div>
                            <!-- Data table -->

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
    </section>
    <!-- /.content -->



<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\rooms\resources\views/dashboard.blade.php ENDPATH**/ ?>
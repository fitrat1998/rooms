<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Xonalar</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Bosh sahifa</a></li>
                        <li class="breadcrumb-item active">Xonalar</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Xonalar</h3>
                        <a href="<?php echo e(route('rooms.create')); ?>" class="btn btn-success btn-sm float-right">
                            <span class="fas fa-plus-circle"></span>
                            Qo'shish
                        </a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.add')): ?>
                        <?php endif; ?>



                        

                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">

                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="building">Binoni tanlang</label>
                                <select id="building" class="form-control select2" name="building">
                                    <option value="">Bino tanlang</option>
                                    <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($building->id); ?>"><?php echo e($building->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="floor">Qavatni tanlang</label>
                                <select id="floor" class="form-control select2" name="floor">
                                    <option value="">Avval binoni tanlang</option>
                                </select>
                            </div>
                        </div>

                            <!-- Data table -->
                            <table id="roomtable"
                                   class="table table-bordered table-striped roomtable dtr-inline table-responsive-lg nowrap" style="width: 1000px"
                                   user="grid" aria-describedby="dataTable_info" width="100%">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Xona raqami</th>
                                    <th>Joylar soni</th>
                                    <th>Qavat</th>
                                    <th>Bino nomi</th>
                                    <th>Izoh</th>
                                    <th>Amallar</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="w-25"><?php echo e($room->id); ?></td>

                                        <td class="w-25"><?php echo e($room->number); ?></td>

                                        <td class="w-25">
                                            <span class="btn btn-success"><?php echo e(count($room->beds)); ?></span>
                                        </td>

                                        <td class="w-25">
                                            <span class="btn btn-primary"><?php echo e($room->floor->number ?? '0'); ?></span>
                                        </td>

                                        <td class="w-25">
                                            <span class="btn btn-success"><?php echo e($room->floor->building->name ?? 0); ?></span>
                                        </td>


                                        <td class="w-25"><?php echo e($room->comment); ?></td>

                                        <td class="text-center">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.delete')): ?>
                                                <form action="<?php echo e(route('rooms.destroy',$room->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="btn-group">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.edit')): ?>
                                                            <a href="<?php echo e(route('rooms.edit',$room->id)); ?>" type="button"
                                                               class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                                                        <?php endif; ?>
                                                        <input name="_method" type="hidden" value="DELETE">
                                                        <button type="button" class="btn btn-danger btn-sm"
                                                                onclick="if (confirm('Вы уверены?')) { this.form.submit() } ">
                                                            <i class="fa fa-trash"></i></button>
                                                    </div>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\rooms\resources\views/rooms/index.blade.php ENDPATH**/ ?>